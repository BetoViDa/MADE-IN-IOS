//
//  SecondView.swift
//  loginswift
//
//  Created by Macías Romero on 09/11/22.
//

import SwiftUI

struct SecondView: View {
    var body: some View {
        Text("Hello, second!")
    }
}

struct SecondView_Previews: PreviewProvider {
    static var previews: some View {
        SecondView()
    }
}
