//
//  DiccionarioView.swift
//  Signa
//
//  Created by Victoria Lucero on 13/11/22.
//

import SwiftUI

struct DiccionarioView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct DiccionarioView_Previews: PreviewProvider {
    static var previews: some View {
        DiccionarioView()
    }
}
